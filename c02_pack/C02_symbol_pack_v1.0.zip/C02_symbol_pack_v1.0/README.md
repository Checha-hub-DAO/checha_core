# C02 — GLOSSARY (Мова / Терміни) · Symbol Pack v1.0
Вміст:
- Radial Waves: badge (128), poster (1200), anim (glow 4s, vibe 3s) у light/dark.
- Voice Line: badge (128), poster (1200), anim (glow 4s, vibe 3s) у light/dark.
Анімації GIF @24fps. _Stamp:_ C02_symbol_pack v1.0 · С.Ч.
