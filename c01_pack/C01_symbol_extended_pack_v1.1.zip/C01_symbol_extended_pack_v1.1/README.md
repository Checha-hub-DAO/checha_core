# C01 — PARAMETERS · Symbol Extended Pack v1.1
Вміст: badges (128), posters (1200), animated (meditative glow 6s @30fps).
_Stamp:_ C01_symbol_extended_pack v1.1 · С.Ч.
